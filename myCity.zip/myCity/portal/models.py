from django.db import models
from datetime import date

class User(models.Model):
    username = models.CharField("User name", max_length=50)
    email = models.CharField('User email', max_length=50)
    password = models.CharField('User Password', max_length=20)
    addr = models.CharField('User Address', max_length=70, default='Not defined')
    phone = models.CharField('User Phone', max_length=10, default='0')
    name = models.CharField('UserName', max_length=30, default='Not defined')
    hehe = models.CharField('hehe', max_length=14, default='Pending')

    def __str__(self):
        return self.username

class Complaint(models.Model):
    # user_id = models.ForeignKey(User,on_delete = models.CASCADE , default='0')
    cuser = models.CharField("Complaintee user", max_length=10 , default=' ') 
    cname = models.CharField("Complaintee",max_length=100 , default='Not Stated')
    cphone = models.CharField("Phone",max_length=100 , default='Not Stated')
    cselect = models.CharField("Select",max_length=100 , default='Not Stated')
    clandmark = models.CharField("Landmark",max_length=100 , default='Not Stated')
    cdescription = models.CharField("Description",max_length=100 , default='Not Stated')
    caddr = models.CharField("Address",max_length=100 , default='Not Stated')
    cpinconde = models.CharField("Pin Code",max_length=100 , default='Not Stated')
    carea = models.CharField("Area",max_length=100 , default='Not Stated')
    status = models.CharField("Status", max_length=15 , default="Pending")

    def __str__(self):
        return self.cuser
    # posted_date = models.DateField(default=date.today)