from django.contrib import admin
from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name="portalHome"),
    path('register/', views.signUp, name="register"),
    path('grievance/', views.grievance, name="grievance"),
    path('submit/', views.submit, name="submit"),
    path('user/',  views.user , name="user"),
    path('logout/', views.logOut, name="logOut"),
    path("register_user/", views.register, name="register_user"),
    path("administrator/", views.administrator, name="administrator"),
    path("admin_pending/", views.admin_pending, name="admin_pending"),
    path("admin_acknowledged/", views.admin_acknowledged, name="admin_acknowledged"),
    path("admin_rejected/", views.admin_rejected, name="admin_rejected"),
    path("update_complaint/", views.update_complaint, name ="update_complaint")
    # path('admin/', views.admin, name="admin"),    
]