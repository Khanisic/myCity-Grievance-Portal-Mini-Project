from django.shortcuts import render,redirect
from django.http import HttpResponse
from .models import *
from django.contrib import messages
from django.contrib.sessions.models import Session

def index(request):
    if request.session.has_key('is_logged'):
        return redirect('user')

    if request.POST:
        username = request.POST['username']    
        password = request.POST['password']

        count = User.objects.filter(username = username , password = password).count()
        if count > 0:
            request.session['is_logged'] = True
            return redirect("user")
        else:
            messages.error(request , "Invalid ID or Password")
            return redirect("portalHome")

    return render(request,"portal/index.html")


def signUp(request):
    if request.session.has_key('is_logged'):
        return redirect('user')

    return render(request,"portal/register.html")

def register(request):
    if request.POST:
        username = request.POST['username']
        email = request.POST['email']
        password = request.POST['password']
        name = request.POST['name']
        addr = request.POST['addr']
        phone = request.POST['phone']

        user_obj = User(username = username , email = email, password = password, name = name, addr = addr, phone = phone)
        user_obj.save()
        messages.success(request,  'You are registered successfully !')
        return redirect('portalHome')

def logOut(request):    
    del request.session['is_logged']
    return redirect('portalHome')

def grievance(request):
    return render(request,"portal/grievance.html")

def submit(request):
    if request.POST:
        cuser = request.POST['cuser']
        cname = request.POST['cname']
        cphone = request.POST['cphone']
        cselect = request.POST['cselect']
        clandmark = request.POST['clandmark']
        cdescription = request.POST['cdescription']
        caddr = request.POST['caddr']
        cpinconde = request.POST['cpinconde']
        carea = request.POST['carea']

        com_obj = Complaint(cuser = cuser , cname = cname, cphone = cphone, cselect = cselect, clandmark = clandmark ,caddr = caddr,cdescription = cdescription, cpinconde = cpinconde, carea = carea )
        com_obj.save()
        return redirect('user')
    return render(request,"portal/submit.html")



def user(request):
    # if request.session.has_key('is_logged'):
    if request.POST:
        user_this = request.POST['username']
        fetch_data = Complaint.objects.filter( cuser = user_this)
        return render(request,"portal/user.html",{'data' : fetch_data})
    return render(request,"portal/user.html")  
    

def administrator(request):
    fetch_complaints = Complaint.objects.all()
    return render(request,"portal/administrator.html",{'data' : fetch_complaints}) 

def admin_pending(request):
    pending_complaints = Complaint.objects.filter(status = 'Pending')
    return render(request,"portal/administrator.html",{'data' : pending_complaints})

def admin_rejected(request):
    rejected_complaints = Complaint.objects.filter(status = 'Rejected')
    return render(request,"portal/administrator.html",{'data' : rejected_complaints})

def admin_acknowledged(request):
    acknowledged_complaints = Complaint.objects.filter(status = 'Acknowledged')
    return render(request,"portal/administrator.html",{'data' : acknowledged_complaints})

def update_complaint(request):
    if request.POST:
        updated = request.POST['updated']
        complainID = request.POST['complainID']
        this_complaint = Complaint.objects.filter( id = complainID)
        if updated == 'Rejected':
            this_complaint.update( status = 'Rejected')
        elif updated == 'Acknowledged':
            this_complaint.update( status = 'Acknowledged')
        return render(request,"portal/administrator.html")
    return render(request,"portal/administrator.html")